<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Demo 01</title>
<!-- Stylesheets -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">
<!--<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">-->
<!--<link rel="icon" href="images/favicon.png" type="image/x-icon">-->
<!-- Responsive -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
</head>
<body class="hidden-bar-wrapper">
<div class="page-wrapper">
    <!-- Preloader -->
    <div class="preloader">
		<span></span>
	</div>
 	<!-- Main Header -->
    <header class="main-header">
        <!-- Header Lower -->
        <div class="header-lower">
			<div class="auto-container">
				<div class="inner-container d-flex justify-content-between align-items-center">
					<div class="logo-box">
						<div class="logo"><a href="index.php"><img src="images/logo.png" alt="" title=""></a></div>
					</div>
					<div class="nav-outer d-flex align-items-center flex-wrap">
						<!-- Main Menu -->
						<nav class="main-menu show navbar-expand-md">
							<div class="navbar-header">
								<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
							</div>
							<div class="navbar-collapse collapse clearfix" id="navbarSupportedContent">
								<ul class="navigation clearfix">
									<li><a href="javascript:">Home</a></li>
									<li><a href="javascript:">About</a></li>
									<li><a href="javascript:">Services</a></li>
									<li><a href="javascript:">Projects</a></li>
									<li><a href="javascript:">Blog</a></li>
									<li><a href="javascript:;">Contact us</a></li>
								</ul>
							</div>
						</nav>
						<!-- Main Menu End-->
					</div>
					<!-- Outer Box -->
					<div class="outer-box d-flex align-items-center flex-wrap">
						<!-- Search Box -->
						<a class="login-box" href="#"><span class="icon flaticon-124-user-2"></span> Login</a>
						<!-- Button Box -->
						<div class="button-box">
							<a href="javascript:;" class="theme-btn btn-style-four"><span class="txt">Contact us</span></a>
						</div>
						<!-- Mobile Navigation Toggler -->
						<div class="mobile-nav-toggler"><span class="icon flaticon-140-menu-3"></span></div>
					</div>
					<!-- End Outer Box -->
				</div>
			</div>
        </div>
        <!-- End Header Lower -->
		<!-- Sticky Header  -->
        <div class="sticky-header">
            <div class="auto-container d-flex justify-content-between align-items-center flex-wrap">
                <!-- Logo -->
                <div class="logo">
                    <a href="index.php" title=""><img src="images/logo.png" alt="" title=""></a>
                </div>
				<!-- Main Menu -->
				<nav class="main-menu">
					<!--Keep This Empty / Menu will come through Javascript-->
				</nav><!-- Main Menu End-->
				<!-- Mobile Navigation Toggler -->
				<div class="mobile-nav-toggler"><span class="icon flaticon-140-menu-3"></span></div>
            </div>
        </div><!-- End Sticky Menu -->
		<!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><span class="icon flaticon-103-cancel-1"></span></div>
            <nav class="menu-box">
                <div class="nav-logo"><a href="index.php"><img src="images/logo.png" alt="" title=""></a></div>
                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
            </nav>
        </div><!-- End Mobile Menu -->
    </header>
    <!-- End Main Header -->
	<!-- Main Slider Section Two -->
    <section class="main-slider-two">
		<div class="vector-one" style="background-image: url(images/main-slider/vector-2.png)"></div>
		<div class="icons-one" style="background-image: url(images/main-slider/icons-layer-2.png)"></div>
		<div class="main-slider-carousel owl-carousel owl-theme">
			<!-- Slide -->
            <div class="slide">
				<div class="auto-container">
					<div class="row clearfix">
						<!-- Content Column -->
						<div class="content-column col-xl-7 col-lg-8 col-md-12 col-sm-12">
							<div class="inner-column">
								<div class="phone">Solutions <a href="tel:+012-345-678-99">+012 (345) 678 99</a></div>
								<h1>Expand your <br> Business using <br> our mind</h1>
								<div class="text">Agency work with top rated talented people provide qulaity services.</div>
								<div class="buttons-box d-flex align-items-center flex-wrap">
									<a href="javascript:;" class="theme-btn btn-style-five"><span class="txt">Discover More</span></a>
									<a class="solution" href="javascript:;">Find Out Solution</a>
								</div>
							</div>
						</div>
						<!-- Image Column -->
						<div class="image-column col-xl-5 col-lg-4 col-md-12 col-sm-12">
							<div class="inner-column">
								<div class="shadow-layer-two" style="background-image: url(images/main-slider/shadow-layer.png)"></div>
								<div class="row clearfix">
									<!-- Column -->
									<div class="column col-lg-6 col-md-6 col-sm-12">
										<div class="image">
											<img src="images/main-slider/image-2.jpg" alt="" />
										</div>
										<div class="image">
											<img src="images/main-slider/image-3.jpg" alt="" />
										</div>
									</div>
									<!-- Column -->
									<div class="column col-lg-6 col-md-6 col-sm-12">
										<div class="image">
											<img src="images/main-slider/image-4.png" alt="" />
											<div class="vector-two" style="background-image: url(images/main-slider/vector-3.png)"></div>
											<div class="vector-three" style="background-image: url(images/main-slider/vector-4.png)"></div>
										</div>
										<div class="image">
											<img src="images/main-slider/image-5.jpg" alt="" />
										</div>
									</div>
								</div>
									
								<!-- Request Box -->
								<div class="request-box">
									<div class="box-inner">
										<span class="icon">
											<img src="images/main-slider/copy.png" alt="" />
										</span>
										Take a step in the <br> right direction
										<a href="javascript:;">Request a call</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Slide -->
            <div class="slide">
				<div class="auto-container">
					<div class="row clearfix">
						<!-- Content Column -->
						<div class="content-column col-xl-7 col-lg-8 col-md-12 col-sm-12">
							<div class="inner-column">
								<div class="phone">Solutions <a href="tel:+012-345-678-99">+012 (345) 678 99</a></div>
								<h1>Expand your <br> Business using <br> our mind</h1>
								<div class="text">Agency work with top rated talented people provide qulaity services.</div>
								<div class="buttons-box d-flex align-items-center flex-wrap">
									<a href="javascript:;" class="theme-btn btn-style-five"><span class="txt">Discover More</span></a>
									<a class="solution" href="javascript:;">Find Out Solution</a>
								</div>
							</div>
						</div>
						<!-- Image Column -->
						<div class="image-column col-xl-5 col-lg-4 col-md-12 col-sm-12">
							<div class="inner-column">
								<div class="shadow-layer-two" style="background-image: url(images/main-slider/shadow-layer.png)"></div>
								<div class="row clearfix">
									<!-- Column -->
									<div class="column col-lg-6 col-md-6 col-sm-12">
										<div class="image">
											<img src="images/main-slider/image-2.jpg" alt="" />
										</div>
										<div class="image">
											<img src="images/main-slider/image-3.jpg" alt="" />
										</div>
									</div>
									<!-- Column -->
									<div class="column col-lg-6 col-md-6 col-sm-12">
										<div class="image">
											<img src="images/main-slider/image-4.png" alt="" />
											<div class="vector-two" style="background-image: url(images/main-slider/vector-3.png)"></div>
											<div class="vector-three" style="background-image: url(images/main-slider/vector-4.png)"></div>
										</div>
										<div class="image">
											<img src="images/main-slider/image-5.jpg" alt="" />
										</div>
									</div>
								</div>
								<!-- Request Box -->
								<div class="request-box">
									<div class="box-inner">
										<span class="icon">
											<img src="images/main-slider/copy.png" alt="" />
										</span>
										Take a step in the <br> right direction
										<a href="javascript:;">Request a call</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Slide -->
            <div class="slide">
				<div class="auto-container">
					<div class="row clearfix">
						<!-- Content Column -->
						<div class="content-column col-xl-7 col-lg-8 col-md-12 col-sm-12">
							<div class="inner-column">
								<div class="phone">Solutions <a href="tel:+012-345-678-99">+012 (345) 678 99</a></div>
								<h1>Expand your <br> Business using <br> our mind</h1>
								<div class="text">Agency work with top rated talented people provide qulaity services.</div>
								<div class="buttons-box d-flex align-items-center flex-wrap">
									<a href="javascript:;" class="theme-btn btn-style-five"><span class="txt">Discover More</span></a>
									<a class="solution" href="javascript:;">Find Out Solution</a>
								</div>
							</div>
						</div>
						<!-- Image Column -->
						<div class="image-column col-xl-5 col-lg-4 col-md-12 col-sm-12">
							<div class="inner-column">
								<div class="shadow-layer-two" style="background-image: url(images/main-slider/shadow-layer.png)"></div>
								<div class="row clearfix">
									<!-- Column -->
									<div class="column col-lg-6 col-md-6 col-sm-12">
										<div class="image">
											<img src="images/main-slider/image-2.jpg" alt="" />
										</div>
										<div class="image">
											<img src="images/main-slider/image-3.jpg" alt="" />
										</div>
									</div>
									<!-- Column -->
									<div class="column col-lg-6 col-md-6 col-sm-12">
										<div class="image">
											<img src="images/main-slider/image-4.png" alt="" />
											<div class="vector-two" style="background-image: url(images/main-slider/vector-3.png)"></div>
											<div class="vector-three" style="background-image: url(images/main-slider/vector-4.png)"></div>
										</div>
										<div class="image">
											<img src="images/main-slider/image-5.jpg" alt="" />
										</div>
									</div>
								</div>
								<!-- Request Box -->
								<div class="request-box">
									<div class="box-inner">
										<span class="icon">
											<img src="images/main-slider/copy.png" alt="" />
										</span>
										Take a step in the <br> right direction
										<a href="javascript:;">Request a call</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Main Slider Section -->
	
	<!-- Services Section Two -->
    <section class="services-section-two">
		<div class="vector-layer" style="background-image: url(images/background/pattern-13.png)"></div>
		<div class="auto-container">
			<div class="inner-container">
				<div class="row clearfix">
					<!-- Service Block Two -->
					<div class="service-block-two col-lg-4 col-md-6 col-sm-12">
						<div class="inner-box">
							<div class="content">
								<span class="icon flaticon-166-bulb"></span>
								<h4><a href="javascript:;">Build a Brand That Grows Business</a></h4>
							</div>
						</div>
					</div>
					<!-- Service Block Two -->
					<div class="service-block-two col-lg-4 col-md-6 col-sm-12">
						<div class="inner-box">
							<div class="content">
								<span class="icon flaticon-203-check-mark"></span>
								<h4><a href="javascript:;">Best digital Solutions Provider</a></h4>
							</div>
						</div>
					</div>
					<!-- Service Block Two -->
					<div class="service-block-two col-lg-4 col-md-6 col-sm-12">
						<div class="inner-box">
							<div class="content">
								<span class="icon flaticon-055-megaphone"></span>
								<h4><a href="javascript:;">Strategy SEO & Paid Media</a></h4>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Services Section Two -->
	<!-- Agency Section Two -->
    <section class="agency-section-two">
		<div class="vector-layer" style="background-image: url(images/background/pattern-9.png)"></div>
		<div class="auto-container">
			<div class="row clearfix">
				<!-- Content Column -->
				<div class="content-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<!-- Sec Title -->
						<div class="sec-title">
							<div class="title">CREATIVE AGENCY</div>
							<h2>We Foster the Growth of Your Digital Business</h2>
						</div>
						<div class="bold-text">There are many variations of passages of in free market to available, but the majority have suffered alteration words</div>
						<ul class="list">
							<li><span class="arrow flaticon-195-right-1"></span>Marketing Strategy</li>
							<li><span class="arrow flaticon-195-right-1"></span>Technology Process</li>
						</ul>
						<div class="text">Digital agency the lorem have suffered alteration Each person brings a unique skill set and perspective to Agency </div>
					</div>
				</div>
				<!-- Image Column -->
				<div class="image-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column" style="background-image: url(images/background/pattern-1.png)">
						<div class="row clearfix">
							<div class="column col-lg-5 col-md-5 col-sm-12">
								<div class="image wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
									<img src="images/resource/agency-1.jpg" alt="" />
								</div>
							</div>
							<div class="column col-lg-7 col-md-5 col-sm-12">
								<div class="image wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
									<img src="images/resource/agency-2.jpg" alt="" />
								</div>
							</div>
							<div class="column col-lg-12 col-md-12 col-sm-12">
								<div class="image wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
									<img src="images/resource/agency-3.jpg" alt="" />
								</div>
								<!-- Service Box -->
								<div class="service-box">
									<div class="box-inner">
										<!-- Explore -->
										<div class="explore">
											Explore <br> 1000+
											<span>Digital Services</span>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Agency Section Two -->
	<!-- Services Section Three -->
    <section class="services-section-three">
		<div class="vector-layer" style="background-image: url(images/icons/vector-2.png)"></div>
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title centered">
				<div class="title">Our Services</div>
				<h2>We're Offering Creative <br> Digital Service</h2>
			</div>
			<div class="row clearfix">
				<!-- Service Block Three -->
				<div class="service-block-three col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="icon flaticon-204-compass"></div>
						<h4>Product Design</h4>
						<div class="text">Lorem ipsum dolor sit amet ipsum consectetur adipiscing elit sed</div>
						<div class="overlay-box" style="background-image: url(images/resource/service.jpg)">
							<div class="overlay-inner">
								<div class="content">
									<a class="get-started" href="javascript:;">view all services <span class="arrow flaticon-right-arrow"></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Service Block Three -->
				<div class="service-block-three col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="icon flaticon-204-compass"></div>
						<h4>Content Analytics</h4>
						<div class="text">Lorem ipsum dolor sit amet ipsum consectetur adipiscing elit sed</div>
						<div class="overlay-box" style="background-image: url(images/resource/service.jpg)">
							<div class="overlay-inner">
								<div class="content">
									<a class="get-started" href="javascript:;">view all services <span class="arrow flaticon-right-arrow"></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Service Block Three -->
				<div class="service-block-three col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="icon flaticon-204-compass"></div>
						<h4>UI Development</h4>
						<div class="text">Lorem ipsum dolor sit amet ipsum consectetur adipiscing elit sed</div>
						<div class="overlay-box" style="background-image: url(images/resource/service.jpg)">
							<div class="overlay-inner">
								<div class="content">
									<a class="get-started" href="javascript:;">view all services <span class="arrow flaticon-right-arrow"></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Service Block Three -->
				<div class="service-block-three col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="icon flaticon-204-compass"></div>
						<h4>Digital Marketing</h4>
						<div class="text">Lorem ipsum dolor sit amet ipsum consectetur adipiscing elit sed</div>
						<div class="overlay-box" style="background-image: url(images/resource/service.jpg)">
							<div class="overlay-inner">
								<div class="content">
									<a class="get-started" href="javascript:;">view all services <span class="arrow flaticon-right-arrow"></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Service Block Three -->
				<div class="service-block-three col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="icon flaticon-204-compass"></div>
						<h4>Company Strategy</h4>
						<div class="text">Lorem ipsum dolor sit amet ipsum consectetur adipiscing elit sed</div>
						<div class="overlay-box" style="background-image: url(images/resource/service.jpg)">
							<div class="overlay-inner">
								<div class="content">
									<a class="get-started" href="javascript:;">view all services <span class="arrow flaticon-right-arrow"></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Service Block Three -->
				<div class="service-block-three col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="icon flaticon-204-compass"></div>
						<h4>Business Intelligence</h4>
						<div class="text">Lorem ipsum dolor sit amet ipsum consectetur adipiscing elit sed</div>
						<div class="overlay-box" style="background-image: url(images/resource/service.jpg)">
							<div class="overlay-inner">
								<div class="content">
									<a class="get-started" href="javascript:;">view all services <span class="arrow flaticon-right-arrow"></span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Services Section Three -->
	<!-- Project Section Two -->
    <section class="project-section-two">
		<div class="vector-layer" style="background-image: url(images/background/pattern-10.png)"></div>
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title">
				<div class="d-flex justify-content-between align-items-center flex-wrap">
					<div>
						<div class="title">Our projects</div>
						<h2>Digital marketing our <br> company's internal history</h2>
					</div>
					<a class="projects" href="javascript:;">View All projects</a>
				</div>
			</div>
			<div class="inner-container">
				<div class="project-carousel owl-carousel owl-theme">
					<!-- Project Block -->
					<div class="project-block">
						<div class="inner-box">
							<div class="image">
								<a href="javascript:;"><img src="images/gallery/1.jpg" alt="" /></a>
							</div>
							<div class="lower-content">
								<div class="d-flex justify-content-between align-items-center flex-wrap">
									<div class="content">
										<div class="title">Strategy</div>
										<h4><a href="javascript:;">Digital experience stategy <br> Development</a></h4>
									</div>
									<div class="button-box">
										<a class="explore" href="javascript:;">explore <span class="arrow flaticon-147-right-arrow-2"></span></a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Project Block -->
					<div class="project-block">
						<div class="inner-box">
							<div class="image">
								<a href="javascript:;"><img src="images/gallery/2.jpg" alt="" /></a>
							</div>
							<div class="lower-content">
								<div class="d-flex justify-content-between align-items-center flex-wrap">
									<div class="content">
										<div class="title">Strategy</div>
										<h4><a href="javascript:;">Digital experience stategy <br> Development</a></h4>
									</div>
									<div class="button-box">
										<a class="explore" href="javascript:;">explore <span class="arrow flaticon-147-right-arrow-2"></span></a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Project Block -->
					<div class="project-block">
						<div class="inner-box">
							<div class="image">
								<a href="javascript:;"><img src="images/gallery/4.jpg" alt="" /></a>
							</div>
							<div class="lower-content">
								<div class="d-flex justify-content-between align-items-center flex-wrap">
									<div class="content">
										<div class="title">Strategy</div>
										<h4><a href="javascript:;">Digital experience stategy <br> Development</a></h4>
									</div>
									<div class="button-box">
										<a class="explore" href="javascript:;">explore <span class="arrow flaticon-147-right-arrow-2"></span></a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Project Block -->
					<div class="project-block">
						<div class="inner-box">
							<div class="image">
								<a href="javascript:;"><img src="images/gallery/1.jpg" alt="" /></a>
							</div>
							<div class="lower-content">
								<div class="d-flex justify-content-between align-items-center flex-wrap">
									<div class="content">
										<div class="title">Strategy</div>
										<h4><a href="javascript:;">Digital experience stategy <br> Development</a></h4>
									</div>
									<div class="button-box">
										<a class="explore" href="javascript:;">explore <span class="arrow flaticon-147-right-arrow-2"></span></a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Project Block -->
					<div class="project-block">
						<div class="inner-box">
							<div class="image">
								<a href="javascript:;"><img src="images/gallery/2.jpg" alt="" /></a>
							</div>
							<div class="lower-content">
								<div class="d-flex justify-content-between align-items-center flex-wrap">
									<div class="content">
										<div class="title">Strategy</div>
										<h4><a href="javascript:;">Digital experience stategy <br> Development</a></h4>
									</div>
									<div class="button-box">
										<a class="explore" href="javascript:;">explore <span class="arrow flaticon-147-right-arrow-2"></span></a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Project Block -->
					<div class="project-block">
						<div class="inner-box">
							<div class="image">
								<a href="javascript:;"><img src="images/gallery/4.jpg" alt="" /></a>
							</div>
							<div class="lower-content">
								<div class="d-flex justify-content-between align-items-center flex-wrap">
									<div class="content">
										<div class="title">Strategy</div>
										<h4><a href="javascript:;">Digital experience stategy <br> Development</a></h4>
									</div>
									<div class="button-box">
										<a class="explore" href="javascript:;">explore <span class="arrow flaticon-147-right-arrow-2"></span></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Project Section Two -->
	<!-- Challenge Section -->
    <section class="challenge-section">
		<div class="auto-container">
			<div class="row clearfix">
				<!-- Title Column -->
				<div class="title-column col-lg-8 col-md-12 col-sm-12">
					<div class="inner-column">
						<!-- Sec Title -->
						<div class="sec-title">
							<div class="title">Our Challenge</div>
							<h2>Our goal is to inspire and challenge to get the best result.</h2>
							<div class="text">I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system</div>
						</div>
					</div>
				</div>
				<!-- Image Column -->
				<div class="image-column col-lg-4 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="image">
							<img src="images/resource/challenge.png" alt="" />
						</div>
						<!-- Button Box -->
						<div class="button-box text-center">
							<a href="javascript:;" class="theme-btn btn-style-one"><span class="txt">know about us</span></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Challenge Section -->
	<!-- Testimonial Section Two -->
    <section class="testimonial-section-two">
		<div class="vector-layer" style="background-image: url(images/background/pattern-4.png)"></div>
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title centered">
				<h2>Client Review What <br> People Say</h2>
			</div>
			<div class="two-item-carousel owl-carousel owl-theme">
				<!-- Testimonial Block Two -->
				<div class="testimonial-block-two">
					<div class="inner-box">
						<div class="quote flaticon-045-right-quote"></div>
						<div class="text">“ We’ve developed expertise around the unique technology and experience challenges facing</div>
						<h3>Great agency</h3>
						<div class="author">
							Troy Dean <span>UI Ux Designer</span>
						</div>
					</div>
				</div>
				<!-- Testimonial Block Two -->
				<div class="testimonial-block-two">
					<div class="inner-box">
						<div class="quote flaticon-045-right-quote"></div>
						<div class="text">“ We've developed expertise around the unique technology and experience challenges facing</div>
						<h3>Great agency</h3>
						<div class="author">
							Troy Dean <span>UI Ux Designer</span>
						</div>
					</div>
				</div>
				<!-- Testimonial Block Two -->
				<div class="testimonial-block-two">
					<div class="inner-box">
						<div class="quote flaticon-045-right-quote"></div>
						<div class="text">“ We've developed expertise around the unique technology and experience challenges facing</div>
						<h3>Great agency</h3>
						<div class="author">
							Troy Dean <span>UI Ux Designer</span>
						</div>
					</div>
				</div>
				<!-- Testimonial Block Two -->
				<div class="testimonial-block-two">
					<div class="inner-box">
						<div class="quote flaticon-045-right-quote"></div>
						<div class="text">“ We've developed expertise around the unique technology and experience challenges facing</div>
						<h3>Great agency</h3>
						<div class="author">
							Troy Dean <span>UI Ux Designer</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Testimonial Section Two -->
	<!-- News Section Two -->
    <section class="news-section-two">
		<div class="vector-layer" style="background-image: url(images/background/pattern-6.png)"></div>
		<div class="auto-container">
			<!-- Sec Title -->
			<div class="sec-title centered">
				<div class="title">Our Blog update</div>
				<h2>Recent Stories Updated</h2>
			</div>
			<div class="row clearfix">
				<!-- News Block Two -->
				<div class="news-block-two col-lg-6 col-md-6 col-sm-12">
					<div class="inner-box">
						<ul class="post-meta">
							<li><a href="javascript:;">15 Aug 2022</a></li>
							<li><a href="javascript:;">Marketing</a></li>
						</ul>
						<h3><a href="javascript:;">Digital Privacy Changes And The Impact On Advertising</a></h3>
						<div class="text">There are many variations of passages of Lorem Ipsum Overcome imposter syndrome using industry</div>
						<div class="d-flex align-items-center">
							<div class="author">
								<div class="author-inner">
									<div class="author-image">
										<img src="images/resource/author-2.png" alt="" />
									</div>
									Anna
								</div>
							</div>
							<a class="read-more theme-btn" href="javascript:;">Read More <span class="arrow flaticon-147-right-arrow-2"></span></a>
						</div>
					</div>
				</div>
				<!-- News Block Two -->
				<div class="news-block-two col-lg-6 col-md-6 col-sm-12">
					<div class="inner-box">
						<ul class="post-meta">
							<li><a href="javascript:;">15 Aug 2022</a></li>
							<li><a href="javascript:;">Marketing</a></li>
						</ul>
						<h3><a href="javascript:;">Digital Privacy Changes And The Impact On Advertising</a></h3>
						<div class="text">There are many variations of passages of Lorem Ipsum Overcome imposter syndrome using industry</div>
						<div class="d-flex align-items-center">
							<div class="author">
								<div class="author-inner">
									<div class="author-image">
										<img src="images/resource/author-2.png" alt="" />
									</div>
									Anna
								</div>
							</div>
							<a class="read-more theme-btn" href="javascript:;">Read More <span class="arrow flaticon-147-right-arrow-2"></span></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End News Section Two -->
	<!-- CTA Section -->
    <section class="cta-section style-two">
		<div class="vector-layer" style="background-image: url(images/background/pattern-5.png)"></div>
		<div class="auto-container">
			<div class="icon flaticon-162-worldwide"></div>
			<h2>A long-term partnership with form <br> and function</h2>
			<div class="text">How do you take high-end customer service</div>
			<div class="button-box text-center">
				<a href="javascript:;" class="theme-btn btn-style-three"><span class="txt">Start work with us</span></a>
			</div>
		</div>
	</section>
	<!-- End CTA Section -->
	<!-- CTA Section Two -->
    <section class="cta-section-two">
		<div class="auto-container">
			<div class="inner-container">
				<div class="pattern-layer" style="background-image: url(images/background/pattern-7.png)"></div>
				<div class="row clearfix">
					<!-- Title Column -->
					<div class="title-column col-lg-6 col-md-12 col-sm-12">
						<div class="inner-column">
							<!-- Sec Title -->
							<div class="sec-title">
								<div class="title">Lets Work Together</div>
								<h2>Subsrcibe for our upcoming latest articles </h2>
							</div>
						</div>
					</div>
					<!-- Form Column -->
					<div class="form-column col-lg-6 col-md-12 col-sm-12">
						<div class="inner-column">
							<!-- Subscribe Box -->
							<div class="subscribe-box">
								<form method="post" action="https://jufailitech.com/envatoitems/GoAge/html/javascript:;">
									<div class="form-group">
										<label>Email Address</label>
										<input type="email" name="search-field" value="" placeholder="Justname@gmail.com" required>
										<button type="submit" class="theme-btn btn-style-two">
											<span class="txt">Subscribe</span>
										</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End CTA Section Two -->
	<!-- Main Footer -->
    <footer class="main-footer style-two">
		<div class="pattern-layer-two" style="background-image: url(images/background/pattern-11.png)"></div>
		<div class="auto-container">
			<!-- Widgets Section -->
            <div class="widgets-section">
				<div class="row clearfix">
					<!-- Column -->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
							<!-- Footer Column -->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget logo-widget">
									<div class="logo"><a href="index.php"><img src="images/logo.png" alt="" title=""></a></div>
									<h4>Welcome</h4>
									<div class="text">We are 150+ specialists across marketing strategy, design</div>
									<!-- Social Box -->
									<ul class="social-box">
										<li><a href="https://www.facebook.com/" class="fa fa-facebook-f"></a></li>
										<li><a href="https://www.twitter.com/" class="fa fa-twitter"></a></li>
										<li><a href="https://www.linkedin.com/" class="fa fa-linkedin"></a></li>
										<li><a href="https://www.instagram.com/" class="fa fa-instagram"></a></li>
									</ul>
								</div>
							</div>
							<!-- Footer Column -->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget links-widget">
									<h5>Links</h5>
									<ul class="links">
										<li><a href="#">About us</a></li>
										<li><a href="#">Meet our team</a></li>
										<li><a href="#">Case stories</a></li>
										<li><a href="#">Latest news</a></li>
										<li><a href="#">Contact</a></li>
										<li><a href="#">Careers</a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<!-- Column -->
                    <div class="big-column col-lg-6 col-md-12 col-sm-12">
						<div class="row clearfix">
							<!-- Footer Column -->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget links-widget">
									<h5>Other Link</h5>
									<ul class="links">
										<li><a href="#">Creative Agency</a></li>
										<li><a href="#">Tearm of user</a></li>
										<li><a href="#">Content strategy</a></li>
										<li><a href="#">Privacy Policy</a></li>
									</ul>
								</div>
							</div>
							<!-- Footer Column -->
                            <div class="footer-column col-lg-6 col-md-6 col-sm-12">
                                <div class="footer-widget links-widget">
									<h5>Our Address</h5>
									<div class="location">Printing House Yard, 15 Hackney Road, London</div>
									<div class="info">
										( 88 ) 100-144574
										<span>oursite@gmail.com</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Footer Bottom -->
			<div class="footer-bottom">
				<div class="auto-container">
					<div class="row clearfix">
						<!-- Column -->
						<div class="column col-lg-6 col-md-6 col-sm-12">
							<div class="copyright">Copyright© 2022 All Rights Reserved</div>
						</div>
						<!-- Column -->
						<div class="column col-lg-6 col-md-6 col-sm-12">
							<ul class="footer-nav">
								<li><a href="#">terms of use</a></li>
								<li><a href="#">privacy policy</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
</div>
<!--End pagewrapper-->
<!-- Scroll To Top -->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-arrow-up"></span></div>
<script src="js/jquery.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/appear.js"></script>
<script src="js/tilt.jquery.min.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/nav-tool.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/script.js"></script>
</body>
</html>